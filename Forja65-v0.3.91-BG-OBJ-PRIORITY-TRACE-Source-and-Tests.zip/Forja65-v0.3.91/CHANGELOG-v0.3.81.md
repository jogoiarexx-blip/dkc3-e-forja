# Forja65 v0.3.81 — Sprite-capture parity & opt-in OBJ/input probe

- Captura de camada OBJ usa `PpuState::buildSpriteRow`, mesma rotina da composição do jogo. Agora respeita dimensões retangulares, flip e prioridade OAM e gera coordenadas/dimensões/pixels por slot. Arquivo NSPR v1 preservado.
- CSV de telemetria **desligado por padrão**: `FORJA65_OBJ_PROBE_PATH`, `FORJA65_OBJ_PROBE_START`, `FORJA65_OBJ_PROBE_INTERVAL`. Coleta estado ao fim do VBlank, PC, WRAM hash, OAM/VRAM hash, joypad, OBSEL, TM/TS e candidatos/visíveis OBJ.
- Novos jogos gerados incluem `obj_capture_probe_smoke` e CTest, além dos testes de banco OBJ da v0.3.80.
- Nenhuma heurística específica do DKC3, nenhuma injeção na CPU/ROM e nenhuma mudança no sistema de gameplay. Não declara Kongs funcionando sem prova de replay.

### Cache de CFG entre versões compatíveis
- `tools/project-io.js`: reutiliza cobertura anterior **somente** quando cada elo da migração consta explicitamente da tabela auditada de versões que não alteram o decoder. Antes, a v0.3.81 só aceitava diretamente a v0.3.80, recusando o cache v0.3.79 produzido pelo port DKC3.
- Mantém obrigatórias a identidade de ROM, esquema de cache, limites de variantes e rejeição de versões anteriores à fronteira sem auditoria.
- `tests/cfg-cache-compatible-v0369-regression.js` e `tests/convergence-metadata-v0372-regression.js`: testam migração encadeada e rejeição de versões incompatíveis.
- Benefício observado: possível regerar código 65816 para o alvo de controle DKC3 `$B8D448` sem jogar fora as rotinas já decodificadas; não equivale a comprovação de gameplay.
