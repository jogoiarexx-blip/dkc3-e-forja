# Forja65 v0.3.82

- Novo `FORJA65_SRAM_PATH`: path opcional para usar SRAM isolada. Protege saves normais em replays, sem alterar o comportamento padrão.
- Novo `FORJA65_FRAME_HASH_PATH`: permite gerar arquivos de hashes de quadro por execução, em vez de compartilhar logs fixos. Sem variável o nome legado continua.
- Cadeia auditada de cache CFG: v0.3.82 pode ler v0.3.81 da **mesma** ROM; CPU e CFG não mudaram nesta versão.
- Casos de regressão JS/C++ para isolamento, além da suíte existente.

**Limites:** isolação de dados não implica que sprites ou movimentos dos Kongs estejam corretos; comprovação exige gameplay e capturas em frames reais.
