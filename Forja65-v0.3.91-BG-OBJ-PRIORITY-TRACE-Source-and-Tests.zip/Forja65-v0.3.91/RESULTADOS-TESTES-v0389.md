# Forja65 v0.3.89 — evidências de testes

- `node tests/obj-oam-order-v0389-regression.js`: PASS (gera e compila runtime C++ sintético, ordem/rotação e BG).
- `node tests/pixel-ownership-v0389-regression.js`: PASS (gera e compila runtime C++ sintético, exportação CSV com confiança da captura).
- `node tests/ppu-sprite-row-regression.js`: PASS, 64 cenas aleatórias, 5 linhas, 2 campos, mutação de segmentos. Referência atualizada para a regra OAM correta; referência histórica preservada.
- Testes direcionados existentes de bank/DMA/OBJ, recarga OAM, prioridade/hires, instrumentação PPU, subscanline e compatibilidade cache passaram individualmente.
- A rodada agregada excedeu o tempo no teste de DMA, e **a suíte completa não foi certificada**. Não considerar esse limite uma falha comprovada do runtime.
- Replay real DKC3: 14050 frames, 13500 de PC/WRAM preservados; imagem e dados gráficos iguais à v0.32 no frame examinado.
- A nova correção é genérica de hardware SNES; a ausência de diferença nesse frame não significa que o ajuste é desnecessário para outros jogos ou estados de sobreposição.
