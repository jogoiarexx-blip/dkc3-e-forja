#!/usr/bin/env bash
# Generic offline SNES OBJ audit; never touches the game ROM or runtime state.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ $# -lt 3 ]];then echo 'Usage: RUN-OBJ-DIAGNOSTICS-v0388-LINUX.sh obj-slots.csv capture_directory output_directory';exit 2;fi
SLOTS="$1";CAPTURE="$2";OUT="$3"
mkdir -p "$OUT"
python3 "$ROOT/tools/obj_assembly_tracker_v0388.py" "$SLOTS" --out "$OUT/assembly-tracks.json"
python3 "$ROOT/tools/nspr_to_png_v0388.py" "$CAPTURE/oam-layer.nspr" --out "$OUT/obj-isolated.png"
python3 "$ROOT/tools/obj_occlusion_audit_v0388.py" "$CAPTURE/preview.ppm" "$CAPTURE/oam-layer.nspr" --out "$OUT/composition.json" --overlay "$OUT/obj-revealed.png"
echo 'FORJA65_OBJ_DIAGNOSTICS_PASS'
