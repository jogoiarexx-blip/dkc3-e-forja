# Forja65 v0.3.82 — SRAM isolada para replay reprodutível

O runtime gerado permite `FORJA65_SRAM_PATH=/caminho/isolado.srm` como substituição **opcional** do caminho `save.srm`. Sem essa variável, o comportamento anterior (incluindo leitura/gravação persistente) é preservado. Replays de regressão podem agora começar com SRAM virgem em uma pasta isolada, sem ler ou sobrescrever os saves do usuário.

O algoritmo 65C816/CFG não muda; cache da v0.3.81 pode ser reutilizado apenas sob ROM idêntica e cadeia explicitamente auditada. O parâmetro de SRAM não faz, por si só, os Kongs aparecerem/andarem.

Testes: `node tests/sram-replay-isolation-v0382-regression.js`; suíte completa `tests/*.js`.
