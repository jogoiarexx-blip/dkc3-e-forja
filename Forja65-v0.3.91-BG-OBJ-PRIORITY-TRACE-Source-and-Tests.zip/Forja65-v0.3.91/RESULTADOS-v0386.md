# Forja65 v0.3.86 — validação direcionada

- `tests/dma-forensics-v0386-regression.js`: APROVADO, compilação de runtime gerado + verificação da transferência para OAM e VRAM e da contagem de ciclos com/sem captura.
- `tests/obj-slot-visibility-v0385-regression.js`: APROVADO, mantém leitura de OBJ por slot.
- `tests/cfg-cache-compatible-v0369-regression.js`: APROVADO, versão anterior permitida exclusivamente pela cadeia auditada da mesma ROM.
- Suíte completa: **não finalizada**; execução integral atingiu o limite de tempo após 6 aprovações iniciais. Não se alega 134/134.
- Os dados DMA só serão conhecidos após compilar e executar o novo jogo em um replay completo. A instrumentação está desligada por padrão.
