# Forja65 v0.3.80 — OBJ address correctness

Correção genérica no runtime/gerador de ports SNES, sem regras de jogo:
- OBSEL $2101: endereço base dos tiles OBJ bits 0-2, segunda página a `(name_select + 1) * 8192` bytes da base (em vez de `name_select * 8192`).
- Única função `PpuState::objNameBase` alimenta ambos os renderizadores de sprites e a captura OAM, evitando novas divergências.
- Wrapping vertical de coordenadas OBJ módulo 256 também no rasterizador, antes presente apenas no exportador de cenas.
- `obj_sprite_bank_smoke` gerado em cada projeto e registrado no CTest cobre transferência DMA e decodificação dos sprites.
- `tests/obj-bank-v0380-regression.js` valida o header realmente gerado e compila/executa o C++ de teste.

Sem mudanças na tradução CPU/CFG, controle de replays v0.3.79, ROM ou formatos das capturas. Limites: teste sintético não substitui replay de jogos reais.

Veja `RESULTADOS-TESTES-v0380.md` para o resultado detalhado de 128 casos Node e os limites da verificação.
