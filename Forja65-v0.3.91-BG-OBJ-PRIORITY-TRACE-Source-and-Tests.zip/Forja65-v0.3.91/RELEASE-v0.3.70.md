# Forja65 v0.3.70 — C++ compactado com preservação de semântica

Base: v0.3.69 deste chat. A lógica de guarda de equivalência, pilha real, dispatcher CFG, cache de cobertura, brilho/PPU e parada headless foi preservada.

- `forja65-core.js`: agrupa variantes geradas SOMENTE se o predicado E/M/X/C e o corpo C++ emitido forem rigorosamente idênticos. Variantes de estados diferentes e corpos diferentes não são fundidos. Mantém a ordem anterior e despacha conflitos.
- `tools/project-io.js`: permite herdar o CFG analisado pela versão imediata v0.3.69 somente para a mesma fingerprint ROM; versões antigas não são aceitas indiscriminadamente.
- `tools/ppu-visibility-audit.js`: separa forced blank, brilho zero, OBJ only e BG habilitado; estado de PPU nunca é prova automática de pixels visíveis.
- Novos testes: `tests/emitter-duplicate-body-v0370-regression.js` e `tests/ppu-visibility-audit-v0370-regression.js`.

13 regressões Node selecionadas passaram; CTest 2/2 no projeto DKC3. O port gerado executou 370 frames completos e capturou o logo Rareware no frame 360; o teste ampliado atingiu o frame 438, mas parou em novo CFG. O executável Windows não foi compilado neste ambiente.
