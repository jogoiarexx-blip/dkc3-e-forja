# Forja65 v0.3.77

Prioriza candidatos de uma tabela FLOW ligada a uma observação ainda não coberta antes de chamadas recuperadas do cache e descendentes de chamadas. RESET e destinos realmente observados mantêm prioridade maior. Peers já previstos por um hint coberto são promovidos por endereço e estado E/M/X/C; continuam candidatos estáticos.

A correção fecha dois casos de esgotamento do orçamento: uma cadeia longa abaixo de um handler observado e uma chamada recuperada do cache que interrompia a fronteira de peers. Peers de tabelas somente cobertas pelo cache permanecem depois das chamadas alcançáveis.

Decoder, emissão de instruções, runtime e verificações de pilha/filler preservados. Cache v0.3.76 aceito como predecessor auditado imediato, com o mesmo fingerprint de ROM. Outros predecessores são rejeitados.

Regressão: `tests/pending-flow-peer-budget-v0377-regression.js`, com ROM sintética, tabela literal, orçamento reduzido, geração incremental, promoção, chamada de cache, despacho emitido e preservação de cobertura. A versão anterior falha. Na tabela real B9E349, análise isolada com hint B9E375 e orçamento 8192 passa de zero para dez destinos alternativos válidos visitados; isso não prova execução desses destinos.

Evidências finais em reports/validation-v0377.json e examples/dkc3-zero-v022. Windows não executado neste ambiente.
