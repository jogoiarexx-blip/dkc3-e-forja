# Forja65 v0.3.78

Limita a prioridade dos candidatos de tabelas FLOW ainda pendentes para que as chamadas do handler observado também recebam orçamento de descoberta. A metade do orçamento global limita o trabalho especulativo enquanto outras rotinas ainda esperam. Chamadas descobertas dentro de um candidato herdam essa proveniência e não passam à frente de dependências reais já enfileiradas.

Um candidato maior que a capacidade prioritária é adiado inteiro. A análise não registra como definitiva uma função parcialmente decodificada só por atingir a reserva: quando o trabalho concorrente termina, a capacidade restante pode concluir o candidato. O teto global e o limite normal por função continuam ativos. RESET, observações, estados E/M/X/C, validação de retornos e barreiras de dados/filler permanecem preservados.

Decoder, emissão de instruções e runtime não mudam. Cache v0.3.77 é o predecessor imediato aceito, vinculado ao mesmo fingerprint de ROM. Outros predecessores não são liberados por esta exceção.

Regressões em `tests/pending-flow-call-budget-v0378-regression.js`: dependência observada competindo com peers grandes, reutilização após dependência barata, descendente especulativo grande de peer pequeno, teto global e guarda de filler. A regressão v0.3.77 de prioridade continua passando. A revisão independente detectou os casos de truncamento e herança especulativa; ambos foram reproduzidos e corrigidos antes da aprovação do scheduler.

A cobertura estática de candidatos não demonstra que esses destinos foram executados nem prova equivalência semântica. O progresso real e os resultados finais da suíte ficam nos relatórios desta versão.
