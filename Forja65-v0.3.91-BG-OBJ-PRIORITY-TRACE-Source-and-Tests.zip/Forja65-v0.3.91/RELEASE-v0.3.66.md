# Forja65 v0.3.66

Core de traducao 65C816 atualizado.

- Forja65 v0.3.65 -> 0.3.66: PPU trace opt-in, CMake PCH e regressao PPU, cache CFG de precursor especificamente compatível.
- `tools/ppu-timeline-report.js` cria diagnostico de visibilidade sem imagens artificiais.
- `tests/ppu-timeline-report-v0366-regression.js` passou.
- Os 7 testes selecionados de CFG/stack passaram.
- Para reproduzir no DKC3, use o projeto v0.11 ao lado desta pasta.
- O projeto C++ do DKC3 completou 120 frames headless; o teste a 300 frames foi interrompido por CFG apos frame 128. Nao ha titulo/mapa visual.
