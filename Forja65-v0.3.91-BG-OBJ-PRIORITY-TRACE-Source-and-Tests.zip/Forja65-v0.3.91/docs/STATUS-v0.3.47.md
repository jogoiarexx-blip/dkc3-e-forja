# Forja65 v0.3.47 — status

The native-dispatch pipeline now validates ROM/span fingerprints, dependency closure, multi-exit continuation sets and explicit shared-state ABI channels before setting `equivalence_proven`. DKC3 commands 21-24 are the first real cross-project consumers of the new shared-state proof rule.
