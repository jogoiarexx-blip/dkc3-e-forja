# Status v0.3.53

O Forja65 agora separa explicitamente as tres camadas do cutover semantico: handlers de comando, callbacks e folhas externas. O plano `native-dispatch` inclui `handler_inventory` e um `family_summary` das folhas externas, ordenado por impacto estrutural.

No DKC3 v0.84 atual: 15/25 handlers de comando, 35/118 callbacks e 37/97 folhas B5/B6 possuem equivalencia semantica ROM-bound. As folhas externas cobrem 127/368 hits (34,5%); 60 folhas / 241 hits continuam fallback. Somando as tres camadas como unidades semanticas independentes, sao 87/240 unidades provadas — esta soma e apenas inventario, nao significa 87 handlers do mesmo dispatcher.
