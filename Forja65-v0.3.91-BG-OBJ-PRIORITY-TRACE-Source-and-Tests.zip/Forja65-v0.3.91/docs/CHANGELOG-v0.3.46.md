# Forja65 v0.3.46 — Multi-Exit Equivalence

- Handler-equivalence proofs now accept `contract.flow_outcomes`.
- PASS verification may report `verification.continuations`; when either side declares multi-exit evidence, the two normalized sets must match exactly.
- Mismatched or missing continuation evidence fails closed before `equivalence_proven`.
- Native-dispatch plans preserve `flow_outcomes` plus `flow_outcomes_verified` in the handler proof record.
- Added `multi-exit-equivalence-v0346-regression.js`.
- DKC3 crossfeed validation: commands 10/11 preserve both `$B9:A11A` and `$B9:A13A`, raising proven animation handlers from 9/25 to 11/25 and structural script-hit coverage from 47.6% to 57.0%.
