# Forja65 v0.3.45 — Batch Equivalence Impact

- `native-dispatch` now consumes optional `script_domain.command_hits` from a ROM-bound bytecode audit.
- Added `handler_impact`, grouping command aliases by unique handler and summing structural script hits.
- Added `cutover.structural_script_hit_coverage` with total/native/candidate hit counts and fractions.
- Added `next_unproven_handlers`, ordered by structural impact, so ports can attack high-return handlers first.
- The metric is explicitly static prioritization evidence, not runtime frequency or whole-game coverage.
- Multi-handler proof packs continue to require exact ROM/span fingerprints and dependency closure before `equivalence_proven` can be set.
