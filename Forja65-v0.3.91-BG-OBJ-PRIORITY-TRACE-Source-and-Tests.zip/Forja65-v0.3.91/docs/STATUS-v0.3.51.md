# Status v0.3.51

O crossfeed consegue provar wrappers de dispatch externo sem confundir hand-off nativo com semantica da folha selecionada. No DKC3 atual, `$B9:BC42` e `$B9:BCA0` usam 97 rotas observadas (60 B6 + 37 B5), cobrindo 368 hits de callback como boundary. As folhas B5/B6 continuam fallback ate prova propria.
