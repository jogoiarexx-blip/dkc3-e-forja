# Forja65 v0.3.48 — Contextual Callback Domain

- `forja65.knowledge.v1` agora preserva `dispatch[].contexts[]`: o mesmo site indireto pode receber domínios diferentes por raiz analisada, sem inflar um handler com alvos pertencentes a outro contexto.
- `focusAnalyze()` aplica o conjunto contextual somente à raiz correspondente e mantém o conjunto global como fallback conservador.
- Novo fechamento genérico `callee-return-index-domain`: reconhece `JSR helper ; [TXY] ; TAX ; JMP (table,X)` quando **todo retorno alcançável** do helper produz um valor finito de A.
- A prova guarda helper, valores de retorno, início da tabela, número de entradas, alvos únicos e `index_bounds_proven=true`.
- No crossfeed DKC3, comandos 3/4 em `$B9:A20F` passam a ter 111 e 7 callbacks contextuais, respectivamente, em vez de ambos herdarem a união de 118.
- O padrão aninhado em `$B9:A8B7` é fechado automaticamente pela análise do helper `$B9:A625`, cujos retornos finitos são `{0,2,4,6,8,10}` e selecionam uma tabela de seis entradas/dois destinos únicos.
- 118/118 callbacks estruturais auditados do lote DKC3 ficam sem `CFG-DYNAMIC`/`FOCUS-DECODE` na análise focal desta versão.

A resolução continua sendo evidência estrutural. Ela não transforma automaticamente callbacks ou handlers em equivalência semântica nativa.
- A fonte `analysis/native-map.js` foi atualizada para preservar `dispatch.resolution` e `dispatch.contexts` durante `normalizeKnowledgePack()`, evitando perda silenciosa da prova no bundle/portable.
