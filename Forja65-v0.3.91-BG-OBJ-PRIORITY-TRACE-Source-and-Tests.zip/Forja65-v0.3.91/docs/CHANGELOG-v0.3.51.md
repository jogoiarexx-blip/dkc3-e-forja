# Forja65 v0.3.51 — External Dispatch Boundary Equivalence

- adiciona `dependency-boundary` como nivel de prova distinto de equivalencia semantica completa;
- verifica fingerprint, evidence spans e postcondicoes das dependencias antes de habilitar uma boundary;
- preserva `equivalence_proven=false` para folhas externas ainda em fallback;
- gera rotas externas auditadas no plano `native-dispatch`;
- mede `dependency_boundary_callbacks`, `dependency_boundary_hits` e `native_or_boundary_fraction`;
- corrige o bundle/normalizacao para preservar a nova evidencia.
