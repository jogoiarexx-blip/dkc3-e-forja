# Status v0.3.48

Esta versão ataca dispatch indireto compartilhado por múltiplos contextos. O Forja agora separa **domínio global conservador** de **domínio contextual por raiz**, e também consegue provar índices vindos de helpers com conjunto finito de retornos em A.

Validação principal do crossfeed DKC3:

- comando 3 `$B9:A1FD`: 746 sites únicos / 828 hits / 111 callbacks;
- comando 4 `$B9:A1E7`: 557 sites únicos / 662 hits / 7 callbacks;
- união: 1.303 sites / 1.490 hits / 118 callbacks;
- 118/118 raízes de callback sem CFG dinâmico após o fechamento do dispatch aninhado `$B9:A8B7`;
- a prova estrutural não autoriza cutover sem uma prova semântica independente.

## Regressão final

A normalização pública do `forja65.knowledge.v1` também foi corrigida para preservar `dispatch.resolution` e `dispatch.contexts`; assim o `bundle-core`/`Forja65-Portable.html` não descarta a evidência contextual ao regenerar o pacote.

Foram aprovadas **15 regressões focais** cobrindo contextual callback domain, callee-return index domain, shared-state, multi-exit, equivalence/dependency closure, bounded/focused crossfeed, state-aware CFG, inline indexed table e regeneração do projeto.
