# Forja65 v0.3.44 — Dependency Closure Crossfeed

- Handler proofs may now include ROM-bound `evidence_spans`; every supplied fingerprint is validated before cutover.
- Added `dependency-abi` equivalence proofs for native dependencies outside the dispatch table itself.
- `equivalence_proven` for a handler with required dependencies now depends on recursive dependency closure, not only on the handler's own label.
- Missing or unproven dependencies fail closed: the native body can remain ready while selective execution stays disabled.
- Generated dispatch JSON now reports `dependencies_verified` and `dependency_closure_proven` for auditable cross-project cutover.
- DKC3 uses this to close `$BB8591` and promote animation command 25 only after the sprite/palette/VRAM teardown dependency passes its own ROM-bound oracle.
