# Forja65 v0.3.45 — batch semantic cutover prioritization

The DKC3 crossfeed currently proves 9 of 25 unique handlers in its animation dispatcher. With ROM-script `command_hits`, Forja65 reports 3,671 of 7,709 audited structural hits on equivalence-proven handlers (47.6%) and 5,715 hits on translation candidates (74.1%).

This status does not mean 47.6% of DKC3 is native. It measures only occurrences in the audited animation bytecode graph. PPU, DMA/HDMA, SPC/DSP, other gameplay dispatchers and unobserved runtime state remain independent work.
