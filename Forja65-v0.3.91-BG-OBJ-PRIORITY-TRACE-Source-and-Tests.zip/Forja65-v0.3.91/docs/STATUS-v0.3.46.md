# Forja65 v0.3.46 — status

The cross-project handler proof pipeline now validates control-flow outcomes as well as ROM/span fingerprints, semantic PASS status and dependency closure. Multi-exit proof metadata is generic and is not tied to DKC3 addresses.

Current DKC3 feedback case: 11/25 unique animation handlers are semantically proven; 4,391/7,709 structural bytecode hits are covered by proven handlers. This is static corpus coverage, not whole-game or runtime-frequency coverage.
