# Status v0.3.50

O crossfeed agora distingue três coisas de forma explícita: equivalência do corpo, fechamento da cadeia de dependências e pós-condições de ABI necessárias pelo chamador.

No DKC3 de referência:

- handlers inteiros equivalentes: **15/25**;
- callbacks estruturais cmd3/4: **118**, 1.490 hits;
- callbacks semanticamente equivalentes: **35/118**;
- hits seletivamente nativos de callback: **548/1.490 = 36,78%**;
- cobertura estática combinada: **5.920/7.709 = 76,79%**;
- cobertura estrutural candidata: **7.205/7.709 = 93,46%**.

A primeira composição que exige pós-condição é `$B9:B84C -> $BB:8591`: o dependency ABI de teardown precisa provar `X=currentSpriteBase` além dos efeitos de memória.

## Regressão focal

Foram aprovadas 15 regressões focais de CFG/dispatch/crossfeed, incluindo a nova `dependency-postcondition-v0350-regression.js`, além das regressões de dependency closure, callback-family, shared-state, multi-exit, contextual callback domain e callee-return indexed dispatch.
