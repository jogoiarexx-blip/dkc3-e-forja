# Forja65 v0.3.52 — External Leaf Impact Cutover

- adiciona escopo de prova `external-leaf-abi`;
- valida fingerprint do span e ABI de shared-state da folha;
- cruza cada folha com callback, accumulator e rota da `dependency-boundary`;
- cruza a contagem de impacto do ranking com a contagem registrada pela prova;
- emite `external_leaf_cutover` com ranking, hits nativos e hits residuais;
- gera `NativeExternalLeafStatus`/`nativeExternalLeaf()` no header C++;
- adiciona regressão contra rota ou impacto adulterados.
