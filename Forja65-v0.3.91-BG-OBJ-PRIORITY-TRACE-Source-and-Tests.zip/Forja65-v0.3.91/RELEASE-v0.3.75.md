# Forja65 v0.3.75 — ROM-backed indirect table priority

- Prioriza targets FLOW realmente observados e, depois, os vizinhos plausíveis em tabelas contíguas de `JSR/JMP (abs,X)` **com bytes da mesma ROM**; preserva RESET em primeiro lugar. As rotinas vizinhas permanecem hipóteses de tradução, não evidências de execução.
- Corrige a regressão do teste de compatibilidade do cache, que tinha predecessores hardcoded desatualizados. Mapeamento de versões permitido continua restrito e vinculado ao fingerprint da ROM.
- Preserva os testes CTest completos e a validação rigorosa de retornos da pilha.
- Foco DKC3 ZERO: sequência de chamadas indiretas em `B9E03C`, tabela em `B9:E042`, durante transição após copyright.

Esta versão não implica progresso visual por si só; exige compilação e execução do port gerado.
