# Forja65 v0.3.89 — Ordem OBJ correta + mapa de proveniência da PPU

**Correção genérica do hardware SNES (runtime gerado)**

- A sobreposição entre OBJ agora respeita a ordem da OAM, incluindo a rotação pelo bit 7 de `$2103` e o cursor OAM interno. Os bits de prioridade de OBJ continuam determinando somente a relação com os BGs.
- Os caminhos `sampleSprites` (pixel) e `buildSpriteRow` (linha) compartilham a regra, preservando a paridade entre renderizador e exportador da camada OBJ.
- Testes sintéticos conferem prioridade entre OBJ, prioridade relativa ao BG, rotação e paridade pixel/linha. Nenhuma ROM é alterada nem há substituição de sprites.

**Diagnóstico opcional, desativado por padrão**

- `FORJA65_CAPTURE_PIXEL_OWNERSHIP=1` adiciona três arquivos à captura normal: `pixel-ownership.csv` (um registro por pixel OBJ opaco), `pixel-winners.ppm` (máscara categórica) e `pixel-ownership-summary.txt`.
- A comparação registra separadamente quem ganhou a composição (OBJ, BG, janela, desabilitado) e se o cálculo de cor alterou o resultado.
- Cada pixel recebe `snapshot_matches_frame`; uma captura estática de registros PPU **não reconstrói necessariamente o estado de raster de todo o frame**, e diferenças não são prova de prioridade incorreta. A máscara e o CSV são apenas instrumentos de diagnóstico.
- Instrumentação apenas durante captura solicitada; sem custo extra no renderizador normal.

**Validação**: testes individuais gerando e compilando o runtime nativo; não implica que todos os jogos gerados sejam idênticos ao SNES. As restrições de 32 sprites/34 tiles por linha e os detalhes completos da rotação em hardware permanecem tópicos separados para futuras verificações.

**Nota de calibração:** uma recomposição offline da camada OBJ exibiu inicialmente 749 pixels de cor diferentes devido ao uso incorreto de outra conversão RGB; depois de igualar o cálculo do exportador, a diferença correta na captura real do DKC3 foi zero. A captura nativa da v0.34 confirma este resultado.
