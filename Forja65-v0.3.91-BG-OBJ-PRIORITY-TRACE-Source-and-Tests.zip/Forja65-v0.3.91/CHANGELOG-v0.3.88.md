# Forja65 v0.3.88 — Diagnóstico de conjuntos OBJ e composição

- Ferramenta genérica `tools/obj_assembly_tracker_v0388.py`: agrupamento heurístico por banco de 32 tiles + bits de paleta. Por frame registra caixa, deslocamento, espelhamento e disposição relativa. Nunca identifica um personagem automaticamente.
- `tools/nspr_to_png_v0388.py`: exporta captura isolada OBJ NSPR v1 para PNG RGBA sem dependências Python externas.
- `tools/obj_occlusion_audit_v0388.py`: compara camada OBJ com preview da composição final e exporta uma imagem de diagnóstico que revela os sprites por cima de uma versão escurecida do cenário. As diferenças não provam, sozinhas, oclusão: podem ser color math, janelas, brilho ou prioridade.
- Scripts Windows/Linux para processar capturas existentes sem reexecutar o jogo.
- Nova versão do núcleo do Forja65, com cadeia auditada de cache CFG da v0.3.87; sem alteração de decodificação de CPU nem da lógica de PPU/DMA/HDMA do jogo.
- Testes unitários cobrindo movimento, espelhamento, transparência, formato PNG, entradas inválidas e comparação OBJ/framebuffer.

**Limites**: ferramentas offline; não corrige automaticamente a prioridade de camadas nem animações. Sem referência de um emulador confiável para o mesmo frame, a identidade dos objetos, seu estado de animação e a fidelidade ao SNES não ficam comprovadas.
