'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path'),cp=require('child_process');
const C=require('../forja65-core.js');
const rom=C.loadRom(C.makeSyntheticRom(),'obj-bank-regression.sfc');
const files=C.generateProject(rom,C.analyze(rom,256,[]));
const runtime=files['src/runtime.hpp'];
assert(runtime.includes('objNameBase(unsigned tile)'),'shared OBJ address resolver missing');
assert(runtime.includes('base=objNameBase(tile)'),'renderer must use shared OBJ address resolver');
assert(runtime.includes('auto row=ppu.buildSpriteRow((int)y);'),'capture must share live OBJ row renderer');
assert(runtime.includes('py=(sy-y+256)&255;'),'point renderer must wrap Y');
assert(runtime.includes('py=(sy-(int)oam[o+1]+256)&255;'),'row renderer must wrap Y');
assert(files['tests/obj_sprite_bank_smoke.cpp'],'missing generated C++ verification');
assert(files['tests/obj_sprite_bank_smoke.cpp'].includes('hw.loadInputReplay(inputProbe)'),'generated runtime input replay verification missing');
assert(files['CMakeLists.txt'].includes('add_test(NAME obj_sprite_bank_smoke'),'missing CTest registration');
const d=fs.mkdtempSync(path.join(os.tmpdir(),'forja-obj-v0380-'));
try{
  fs.mkdirSync(path.join(d,'src'));
  fs.writeFileSync(path.join(d,'src/runtime.hpp'),runtime);
  fs.writeFileSync(path.join(d,'verify.cpp'),files['tests/obj_sprite_bank_smoke.cpp']);
  const b=cp.spawnSync(process.env.CXX||'c++',['-std=c++20','-O0','-I'+path.join(d,'src'),path.join(d,'verify.cpp'),'-o',path.join(d,'verify')],{encoding:'utf8'});
  assert.strictEqual(b.status,0,b.stderr||String(b.error));
  const r=cp.spawnSync(path.join(d,'verify'),[],{encoding:'utf8'});
  assert.strictEqual(r.status,0,r.stderr||String(r.error));
  assert(r.stdout.includes('FORJA65_OBJ_BANK_DMA_WRAP_PASS'));
  console.log('OBJ banks / DMA / Y-wrap v0.3.80: PASS');
}finally{fs.rmSync(d,{recursive:true,force:true});}
