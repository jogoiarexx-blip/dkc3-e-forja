# Forja65 v0.3.65 — Stack Return Validation + State-aware CFG verification

- Retorno `RTS/RTL` agora distingue *um endereço compilado* de *um destino de retorno/trampolim identificado por análise ou observação*. O gerador emite `kForja65StackReturnOffsets` e autoriza somente destinos nesse conjunto, desde que presentes no dispatcher. Suporta mirrors por offset de ROM.
- Retornos incompatíveis não podem terminar silenciosamente apenas porque o destino não foi mapeado na ROM. `unresolvedReturn` grava PC, destino, tipo de retorno, SP, profundidade da pilha nativa e alvo de retorno esperado; interrompe a execução para diagnóstico.
- `tools/verify-learned-cfg.js` v2 testa as variantes CPU E/M/X/C em vez de apenas verificar se o endereço aparece no dispatcher. Uma variante genérica em carry também é aceita quando explicitamente compilada.
- Regressão `tests/stack-return-authorization-v0365-regression.js` comprova que um label compilado não vira um retorno calculado autorizado automaticamente.
- Não há equivalência gráfica ou gameplay validada: esses são testes de infraestrutura. Variantes aprendidas precisam ser recompiladas e executadas.

## Monotonic CFG coverage cache

- `tools/project-io.js` now saves `analysis/cfg-coverage-cache.json` and merges its ROM-decoded functions with new analysis results only when cache schema, ROM hash **and Forja65 version** match. A 32768-variant ceiling causes an explicit error instead of discarding coverage.
- This fixes observed loss of CFG coverage after adding a runtime hint: the DKC3 generation recovered 5058 old decoded addresses and reached 5916 distinct compiled addresses with 18 state-aware verified runtime hints.
- `tests/monotonic-cfg-cache-v0365-regression.js` covers retention, ROM mismatch, version mismatch and capacity protection.
- Important limitation: the cache retains byte-derived instructions, not execution proofs. It does not make previously untested paths semantically equivalent, and runtime validation remains required.
