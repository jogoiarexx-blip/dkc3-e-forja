# Forja65 v0.3.81 — diagnóstico de sprites em ports SNES

O gerador passa a exportar a camada de OBJ com o mesmo rasterizador usado na tela: isso corrige as capturas de sprites não quadrados, com prioridade OAM consistente e contagem de pixels por slot. Cada port gerado tem novo `obj_capture_probe_smoke` automático.

O CSV opcional `FORJA65_OBJ_PROBE_PATH` registra amostras de PC, joypad, WRAM, VRAM e OAM (hashes), contagem de OBJ visíveis/candidatos e registradores de exibição. Controle de coleta `FORJA65_OBJ_PROBE_START` (frame inicial) e `FORJA65_OBJ_PROBE_INTERVAL` (periodicidade). O jogo não é modificado por este diagnóstico.

A v0.3.80 já havia corrigido o endereçamento OBSEL e a volta em Y. A v0.3.81 é adicional e genérica. Não há prova de que o movimento do Kong esteja consertado.

**Migração de cache CFG:** a versão 0.3.81 suporta reutilizar cache de uma versão anterior através de uma cadeia **completa** de transições explicitamente auditadas. A checagem de hash da ROM continua obrigatória. Caso o cache seja de uma versão que alterou decoder/CFG, a geração recusa o arquivo e deve ser refeita com a ROM de origem. Os testes `cfg-cache-compatible-v0369` e `convergence-metadata-v0372` cobrem a regra.

**Validação final (Linux/Node):** suíte completa `tests/*.js` com **129 aprovados, 0 falhas** após a atualização da migração de cache CFG. A suíte também compila e executa testes de código C++ gerado para OBJ/DMA e paridade de captura. Compilação Windows deve ser realizada no PC do usuário.
