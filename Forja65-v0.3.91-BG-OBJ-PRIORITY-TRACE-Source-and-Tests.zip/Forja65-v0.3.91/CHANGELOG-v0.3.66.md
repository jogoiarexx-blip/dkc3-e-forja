# Forja65 v0.3.66 — diagnóstico PPU e continuação da tradução do DKC3

- `FORJA65_PPU_TRACE=1` emite `forja65-ppu-timeline.csv` com snapshots reais dos registradores por frame e logs selecionados das escritas que controlam visibilidade. Desligado por padrão: não altera o estado do SNES virtual.
- `tools/ppu-timeline-report.js` resume por frame `FORCED_BLANK`, `LAYERS_DISABLED` e `DISPLAY_ENABLED_POSSIBLE` sem fabricar uma imagem.
- `tests/ppu-timeline-report-v0366-regression.js`: teste de classificação e validação de CSV.
- O teste C++ `tests/ppu_timeline_smoke.cpp`, fornecido no projeto DKC3, compila e verifica as escritas reais em $2100/$2105/$212C/$212D.
- Cache CFG pode importar **somente** o cache do precursor `0.3.65-stack-return-validation`, pois a mudança deste release não altera o decoder; os demais casos continuam rejeitados.
- Execução real do DKC3 chegou e completou 120 frames, mas ainda estava em forced blank, sem tela gráfica. Novo avanço exige execução e validação dos caminhos além do frame 120.
