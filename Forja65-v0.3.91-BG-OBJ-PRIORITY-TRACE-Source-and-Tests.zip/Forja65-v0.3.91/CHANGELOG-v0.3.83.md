# Forja65 v0.3.83

- `learn-crash` no longer writes `analysis/runtime-hints.txt` **before** rebuilding the CFG. A rejected cache, ROM check, or invalid `--max` leaves the previous verified hints untouched.
- ROM-bound checks for STACK-RTS/RTL observations remain mandatory; learning never bypasses runtime returns or invents control flow.
- Same-ROM audited cache reuse from v0.3.82 is permitted because the decoder and C++ emitter are unchanged.
- Regression test covers failed learning without changing existing runtime-hints.

All updates are independent of the DKC3-specific addresses.
