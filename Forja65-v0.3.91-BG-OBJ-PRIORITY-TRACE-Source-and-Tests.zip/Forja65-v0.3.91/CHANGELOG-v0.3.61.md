# Forja65 0.3.61 (diagnostic automation bundle)
Added cycle scripts integrating existing learn-crash -> native generated CFG -> fast Debug build -> headless verification. These are reusable examples and are not a new CPU opcode/semantic implementation. DKC3 validates learning 2 previously missing CFG destinations; additional branches remain unresolved.
