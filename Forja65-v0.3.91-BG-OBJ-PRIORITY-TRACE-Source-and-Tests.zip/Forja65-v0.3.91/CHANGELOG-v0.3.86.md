# Forja65 v0.3.86 — rastreamento de origem DMA sem efeitos colaterais

- `FORJA65_DMA_FORENSICS_PATH`: opcional, desligado por padrão, CSV por canal DMA; exporta frame, PC, modo, origem, contagens para OAM/VRAM/CGRAM, endereços de registro e hash dos bytes *efetivamente transferidos*.
- `FORJA65_DMA_FORENSICS_START` e `FORJA65_DMA_FORENSICS_END`: recorte de frames para impedir crescimento indesejado dos arquivos.
- Não relê ROM/RAM/I/O: contabiliza bytes já acessados pelo caminho DMA. Não altera CPU/PPU, tempo de execução emulada nem lógica do jogo. O custo extra existe apenas quando habilitado.
- Novo teste `tests/dma-forensics-v0386-regression.js`: compara transferências OAM/VRAM com e sem rastreador e verifica filtro por frame.
- CFG/CPU inalterados: cache v0.3.85 permitido somente para mesma ROM pela cadeia explicitamente auditada.
- Não contém correção de sprites do DKC3 nem declaração de Kongs jogáveis.
