# Forja65 v0.3.83 — validação

Suíte `node tools/test.js`: primeira execução **130/131** aprovações. A única falha foi `cfg-cache-compatible-v0369-regression.js`, pois a expectativa de versão foi deixada em v0.3.82. Após atualizar a tabela do teste para a cadeia auditada v0.3.83 → v0.3.82, ele **passou isoladamente**; não foi realizada uma segunda execução completa da suíte.

`transactional-crash-learning-v0383-regression.js`: PASS. O teste provoca uma incompatibilidade de cache e uma falha injetada *depois de escrever* `analysis/runtime-hints.txt`. O conteúdo permanente anterior foi preservado/restaurado.

`observed-stack-return-v0367-regression.js`: protege validação de instrução RTS/RTL e evidência exata para hints calculados. Não foi relaxada.

No DKC3, o Forja65 v0.3.83 regenerou os novos destinos observados sem mudar o decodificador ou alterar a ROM. DKC3-ZERO v0.28 compilou e passou no CTest, mas a jogabilidade dos Kongs ainda exige observação visual.
