# Forja65 v0.3.85 — investigação OBJ por slot

- Novo `FORJA65_OBJ_SLOTS_PATH` (desligado por padrão), usado junto de `FORJA65_OBJ_PROBE_PATH`. Exporta, a cada frame amostrado, **somente os slots OAM que produziram pixels opacos após a prioridade entre OBJ**, com coordenadas brutas, dimensões, tile, atributos, pixels e limites visíveis.
- Dados lidos do renderizador de linhas `buildSpriteRow`, sem modificar PPU, CPU, WRAM, OAM, VRAM ou controles. Ausência na lista não prova ausência da entidade na lógica do jogo: pode indicar sprites transparentes, fora da tela, mascarados por outros sprites, ou ausência de escrita em OAM.
- O CSV anterior permanece idêntico para compatibilidade de ferramentas. A coleta só ocorre se ambos os caminhos estiverem configurados.
- `tests/obj-slot-visibility-v0385-regression.js` verifica uma amostra pixel-a-pixel e a mudança de coordenadas em dois frames sintéticos.
- Cache da v0.3.84 reutilizável somente pela cadeia explicitamente auditada e pela mesma ROM.
