# Forja65 v0.3.76 — prioridade CFG e diagnóstico PPU

Esta versão incorpora destinos observados ainda ausentes e seus descendentes antes de rotinas já compiladas, preserva o cache anterior e dá prioridade aos candidatos plausíveis de tabelas de retorno. RESET continua primeiro. A compatibilidade com o cache v0.3.75 preserva decoder e emitter; candidatos estáticos não são contabilizados como equivalência provada.

O diagnóstico PPU agora usa stream persistente por instância, encerramento por RAII, truncamento por execução e caminhos distintos entre runtime e testes. O CTest isola o ambiente de todos os testes e somente ppu_timeline_smoke habilita rastreamento. Builds Windows padrão e de qualidade copiam executável e assets antes dos testes.

`analyze --cache-limit N` persiste o teto explícito de cobertura; `converge --jobs N` controla o paralelismo. Consulte CHANGELOG-v0.3.76.md e reports/validation-v0376.json para detalhes e limites de validação.

O DKC3 ZERO v0.20 confirma título, seleção de save, opções e save DIXIE por execução original da ROM. O estado do mapa e da primeira fase é informado no pacote DKC3, não inferido da contagem de instruções recompiladas. Windows não foi executado neste ambiente.
