# Forja65 v0.3.79

A leitura dos controles do host retorna sem alterar os botões enquanto um replay válido está ativo. No Windows, a consulta a teclado/XInput durante o vblank podia zerar ou substituir os botões gravados. O modo manual conserva a leitura e liberação normal dos botões.

Regressão executa o corpo Windows gerado de pollInput com as APIs do sistema simuladas: entrada mantida durante consultas repetidas, nenhuma consulta ao host durante replay e controle manual funcional depois. Isso valida o corpo da função; o aplicativo Windows completo não foi executado neste ambiente.

Decoder e análise de CFG não mudam. O predecessor imediato aceito é v0.3.78, ligado à mesma ROM.

Suíte: 127/127 PASS. Evidências e limites em reports/progression-v024.json.
