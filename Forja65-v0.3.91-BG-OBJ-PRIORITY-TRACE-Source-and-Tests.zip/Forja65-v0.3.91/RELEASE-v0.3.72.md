# Forja65 v0.3.72 — Convergence build reuse + PPU audit

- `converge` now supports `--build-dir /path/to/existing-build`; it reuses the project's incremental C++ build rather than creating a new one, avoiding unnecessary first-pass compiles.
- `--ppu-trace` captures raw PPU register state in each isolated convergence run and adds a visibility **state** audit to the per-round JSON report. It makes no claim about visible pixels or correct graphics without a rendered capture.
- The standalone PPU visibility auditor now rejects a CSV that concatenates multiple runs (frame indices restarting). This previously caused inflated sampled-frame counts during repeated DKC3 testing.
- Without `--max`, convergence reuses `analysis/generation-options.json` instead of accidentally changing the analysis budget.
- When an existing `CMakeCache.txt` is found, `converge` preserves its configured build type/trace settings rather than forcing Release and invalidating all object files.
- Stack-RTL/RTS proofs, ROM fingerprint checks, and the v0.3.71 safety guard remain unchanged.
- Cache compatibility extends **only** to the immediate predecessor v0.3.71, because ROM analysis and instruction emission semantics have not changed in v0.3.72.

Example: `node tools/forja65.js converge /path/DKC3-ZERO --frames 750 --rounds 16 --build-dir /path/DKC3-ZERO/build-native --ppu-trace --max 8192`.
