# Forja65 v0.3.63 - verified scope

- Five JS regression suites passed: CFG hot-call priority, safe fallthrough, direct CFG, NMI vector CFG and carry-aware CFG.
- Generated synthetic LoROM with one NOP and a tight CFG budget; complete CMake PCH-enabled build passed 6/6 tasks, executable returned exit 2 as expected at previously uncompiled `008000 -> 008001`, and a ROM-fingerprint-bound `FLOW` hint was emitted.
- DKC3 v0.7 (prior Forja version) real headless run reached `00BBF5 -> 00BC0B`, exit 2. DKC3 v0.8 CFG verification passed 6/6 known targets, but its full build is unfinished. No DKC3 visual frame has been verified.
