@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if "%~3"=="" (echo Usage: %~nx0 obj-slots.csv capture_directory output_directory & exit /b 2)
where py >nul 2>nul
if errorlevel 1 (echo Python 3 required. & exit /b 3)
if not exist "%~3" mkdir "%~3"
py -3 "%~dp0tools\obj_assembly_tracker_v0388.py" "%~1" --out "%~3\assembly-tracks.json"
if errorlevel 1 exit /b 4
py -3 "%~dp0tools\nspr_to_png_v0388.py" "%~2\oam-layer.nspr" --out "%~3\obj-isolated.png"
if errorlevel 1 exit /b 5
py -3 "%~dp0tools\obj_occlusion_audit_v0388.py" "%~2\preview.ppm" "%~2\oam-layer.nspr" --out "%~3\composition.json" --overlay "%~3\obj-revealed.png"
if errorlevel 1 exit /b 6
echo FORJA65_OBJ_DIAGNOSTICS_PASS
exit /b 0
