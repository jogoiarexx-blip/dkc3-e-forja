# Forja65 v0.3.74

Correção no gerador dos scripts `BUILD-WINDOWS.cmd` e `BUILD-QUALITY-WINDOWS.cmd`: todos os alvos (ALL_BUILD), incluindo os dois smoke tests PPU e orçamento headless, são compilados antes do `ctest`. Assim o relatório não acusa falsamente `no such file or directory`. O parâmetro `--parallel 2` limita o paralelismo durante o build pesado. Não se omitem testes.

Preserva os mecanismos de CFG, pilha, PPU e compilação seletiva da v0.3.73.
