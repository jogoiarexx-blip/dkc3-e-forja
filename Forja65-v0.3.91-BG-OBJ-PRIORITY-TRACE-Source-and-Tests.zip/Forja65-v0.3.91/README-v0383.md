# Forja65 v0.3.83 — aprendizado CFG transacional

Esta versão corrige a persistência dos hints durante `node tools/forja65.js learn-crash <projeto> --from <diagnosticos> --max 65536`.

Antes, `analysis/runtime-hints.txt` era gravado antes de a regeneração concluir. Agora os novos hints só são consolidados após geração bem-sucedida. Se a geração falhar, os hints verificados previamente são restaurados, inclusive se a falha vier depois de começar a escrever os arquivos gerados. Falhas de geração não são silenciosamente convertidas em sucesso.

A validação de retornos `STACK-RTS` e `STACK-RTL` continua exigindo instrução correta na ROM e evidência exata do runtime. A cadeia auditada de cache permite a v0.3.82 da **mesma ROM**; decodificador 65C816 e emissor C++ não mudaram neste incremento.

Testes dirigidos:

```bash
node tests/transactional-crash-learning-v0383-regression.js
node tests/cfg-cache-compatible-v0369-regression.js
node tests/observed-stack-return-v0367-regression.js
```

Suite completa: `node tools/test.js` (executada no fechamento da versão).

Esta ferramenta não reconhece automaticamente os Kongs; prova de movimento e sprites depende de replays e capturas do projeto DKC3.
